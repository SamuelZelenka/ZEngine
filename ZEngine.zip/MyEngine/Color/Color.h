#pragma once

typedef unsigned char uint8;

struct Color
{
public :
	uint8 r;
	uint8 g;
	uint8 b;
	uint8 a;
};