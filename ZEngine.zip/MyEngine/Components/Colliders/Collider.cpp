#include "Collider.h"	
#include "../../Physics/PhysicsManager.h"
#include "../../Game/game.h"


void Collider::init()
{
	gameObject->game->physicsManager->add_collider(this);
};