#include "Component.h"
#include "../GameObject/GameObject.h"


Component::~Component()
{

}

void Component::init()
{
}

void Component::awake()
{
}

void Component::update()
{
}
