#include "../PrefabOriginals/CollisionBox.h"
#include "../../GameObject/GameObject.h"
#include "../../Components/Colliders/Collider.h"
#include "../../Components/RectRenderer.h"
#include "SDL.h"

void CollisionBox::construct_components(GameObject* object)
{
	SDL_Color color = { 0,0,255,255 };
	object->add_component(new AABBCollider(object, object->position, 25, 600, true));
	object->add_component(new RectRenderer(object, 25, 600, color, 2));
}