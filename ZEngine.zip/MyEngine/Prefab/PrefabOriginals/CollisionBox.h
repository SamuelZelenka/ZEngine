#pragma once
#include "../Prefab.h"

class GameObject;


class CollisionBox : public Prefab
{
public:
	CollisionBox() : Prefab() {};
	void construct_components(GameObject* object) override;
};

